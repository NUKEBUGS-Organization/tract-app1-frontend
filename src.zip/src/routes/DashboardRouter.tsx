import { Navigate } from "react-router";

import DashboardLayout from "../layouts/DashboardLayout";

import { useAuthContext } from "../contexts/AuthContext";
import { tokenStorage } from "../redux/auth/tokenStorage";
import { getRoleFromToken } from "../redux/auth/jwtUtils";
import { useThemeMode } from "../hooks/useThemeMode";

import {
  ADMIN_ROLES,
  PARTNER_ROLES,
  REALTOR_ROLES,
  SELLER_ROLES,
  isAllowedRole,
  normalizeRole,
} from "../constants/roles";

const sellerNav = [
  { label: "Dashboard", path: "/dashboard" },
  { label: "List Property", path: "/list-property" },
  { label: "Document Vault", path: "/document-vault" },
  { label: "View Bids", path: "/bids" },
  { label: "Contracts", path: "/contracts" },
  { label: "Deal Tracker", path: "/deal-tracker" },
  { label: "Chat", path: "/chat" },
];

const partnerNav = [
  { label: "Dashboard", path: "/dashboard" },
  { label: "Property Stream", path: "/properties" },
  { label: "My Bids", path: "/my-bids" },
  { label: "Active Deals", path: "/deals" },
  { label: "Chat", path: "/chat" },
];

const realtorNav = [
  { label: "Dashboard", path: "/dashboard" },
  { label: "Properties", path: "/properties" },
  { label: "Deals", path: "/deals" },
  { label: "Chat", path: "/chat" },
];

const adminNav = [
  { label: "Dashboard", path: "/dashboard" },
  { label: "State Firewall", path: "/states" },
  { label: "Users", path: "/users" },
  { label: "Verifications", path: "/verifications" },
  { label: "Deals", path: "/deals" },
  { label: "Chat Flags", path: "/chat-flags" },
];

export default function DashboardRouter() {
  const { role, accessToken } = useAuthContext();

  const token = accessToken || tokenStorage.getAccessToken();
  const userRole = normalizeRole(role || getRoleFromToken(token));

  const isPartner = isAllowedRole(userRole, PARTNER_ROLES);

  const { mode, toggleMode } = useThemeMode(isPartner ? "partner" : "other");

  if (isAllowedRole(userRole, SELLER_ROLES)) {
    return (
      <DashboardLayout
        title="Seller Portal"
        navItems={sellerNav}
        mode="light"
      />
    );
  }

  if (isPartner) {
    return (
      <DashboardLayout
        title="Partner Pro Mode"
        navItems={partnerNav}
        mode={mode}
        onToggleTheme={toggleMode}
        showThemeToggle
      />
    );
  }

  if (isAllowedRole(userRole, REALTOR_ROLES)) {
    return (
      <DashboardLayout
        title="Licensed Partner Portal"
        navItems={realtorNav}
        mode="light"
      />
    );
  }

  if (isAllowedRole(userRole, ADMIN_ROLES)) {
    return (
      <DashboardLayout
        title="Admin Portal"
        navItems={adminNav}
        mode="light"
      />
    );
  }

  return <Navigate to="/unauthorized" replace />;
}
